import React from 'react'
 
const About = () => {
  return (
    <div className='container'>
    <div className='py-4'>
  <h1>ABOUT PAGE</h1>
  <p className='lead'>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum, nostrum! Nulla corporis qui minima ipsum cum autem quae id necessitatibus! Veniam soluta repellat consequatur, dolor aliquid architecto quibusdam sint nemo quae quis tempora magnam rem assumenda enim quidem unde sequi.
  </p>
  </div>
</div>
  )
}
 
export default About;