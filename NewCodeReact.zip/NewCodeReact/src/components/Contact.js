import React from 'react'

function Contact() {
  return (
    <div className='container'>
        <div className='py-4'>
        <h1>Contact</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto praesentium consequatur nihil, error perspiciatis impedit tempore repudiandae deleniti quis rerum! Distinctio officiis quo blanditiis! Nesciunt tempore officia asperiores recusandae perspiciatis.</p>
        </div>
    </div>
  )
}

export default Contact
